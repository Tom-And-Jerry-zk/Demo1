package com.zhang.helloController;


import com.zhang.pojo.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;



/**
 * Created by Administrator on 2019/8/20.
 */


@Controller
public class helloApplication {

    @RequestMapping("/test1")
    @ResponseBody
    public String test1(){
        return "hello1";
    }



    @Autowired
    private Student student;

    @RequestMapping("/test2")
    @ResponseBody
    public Student test2(){
        return student;
    }


}
