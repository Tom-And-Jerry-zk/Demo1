package com.zhang;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


//1.注解
@SpringBootApplication
public class Boot1Application {

	//2.main函数
	public static void main(String[] args) {


		//3.启动，目的扫描com.zhang 下面的包
		SpringApplication.run(Boot1Application.class, args);
	}

}
